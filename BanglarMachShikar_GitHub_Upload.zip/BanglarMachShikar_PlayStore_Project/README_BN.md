# বাংলার মাছ শিকার — Play Store project

এটি একটি lightweight Android game project। এতে playable fishing loop, score/coin, level, mission, bag, shop এবং local save আছে।

## Play Store-এর জন্য
Google Play-এর বর্তমান নিয়ম অনুযায়ী (31 August 2026 থেকে) নতুন app/update-কে Android 16 (API 36) বা তার বেশি target করতে হবে। এই project-এ `targetSdk 36` সেট করা আছে। নতুন Play apps-এর জন্য Android App Bundle (AAB) ব্যবহার করতে হবে।

## Build
1. Android Studio-তে এই folder open করুন।
2. Gradle sync করুন।
3. `Build > Generate Signed Bundle / APK > Generate Signed Bundle` নির্বাচন করুন।
4. Release হিসেবে `.aab` তৈরি করুন।
5. নিজের Play Console account-এ app তৈরি করে AAB upload করুন।

## গুরুত্বপূর্ণ
- এখানে সরাসরি signed AAB তৈরি করা হয়নি, কারণ এই পরিবেশে Android SDK/Gradle build tool ইনস্টল নেই।
- Play Store-এ প্রকাশের আগে app icon, privacy policy, screenshots, content rating, data safety এবং store listing সম্পূর্ণ করতে হবে।
- Package name: `com.banglarmachshikar.game`


## Version 1.1 gameplay upgrade
- Energy + bait resource loop
- XP and level-up
- Four fish types including ইলিশ
- Fishing locations screen
- River unlock
- Quick shop/bag buttons
- Local save retained

## Publishing checklist
- Create a unique app icon and feature graphic.
- Add screenshots from real gameplay.
- Add a privacy policy URL if the app collects any data.
- Complete Play Console Data safety, content rating, target audience and store listing.
- Create a release keystore and keep the signing key backed up securely.
- Build and test the signed AAB on multiple Android versions/devices before release.


## Version 1.2
- Richer in-game HUD and XP bar
- Underwater bubbles/ripples
- Fish name hints
- Pause/resume screen
- Energy/bait validation
- Expanded persistent catch stats
- Improved fishing button feedback
